//**student code change start**
<template>
 <div>
    <div>
      <h1>API</h1>
      <p>Klik op de knop om de API op te roepen!
      </p>

      <button @click="callApi">API</button>
    </div>

    <div v-if="apiMessage">
      <h2>Resultaat</h2>
      <p>{{ apiMessage }}</p>
    </div>

 </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      apiMessage: null
    };
  },
  methods: {
    async callApi() {
      const accessToken = await this.$auth.getAccessToken();

      try {
        const { data } = await axios({
  method:'get',
  url:'https://tuamapi.azurewebsites.net/api/private-scoped',
  headers: {
            Authorization: `Bearer ${accessToken}`
          }
        });
        this.apiMessage = data.message;
      } catch (e) {
        this.apiMessage = `Error: the server responded with '${ e.response.status }: ${e.response.statusText}'`; }
    }
  }
};
</script>
//**student code change end**
