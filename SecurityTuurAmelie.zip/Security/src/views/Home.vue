<template>
<div>
<h1> a sandboxed iframe </h1>
<iframe width=85% height= 550px sandbox="allow-scripts allow-popups allow-same-origin" src="https://sintlievens.eu"></iframe>
</div>
</template>


<script>
export default {
  name: "home"
};
</script>

<style lang="scss" scoped>
.next-steps {
  .fa-link {
    margin-right: 5px;
  }
}
</style>
